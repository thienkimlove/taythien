<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin</title>

    <!-- Custom Fonts -->
    <link href="<?php echo e(url('/css/admin.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(url('/css/select2.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(url('js/datetimepicker/build/jquery.datetimepicker.min.css')); ?>" rel="stylesheet" />


</head>

<body>

<div id="wrapper">

    <?php echo $__env->make('admin.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div id="page-wrapper">
        <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div>


</div>
<script>
    var Config = {};
    window.baseUrl = '<?php echo e(url('/')); ?>';
</script>

<script src="<?php echo e(url('/js/admin.js')); ?>"></script>
<script src="<?php echo e(url('/bower_components/ckeditor/ckeditor.js')); ?>"></script>
<script src="<?php echo e(url('/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(url('js/datetimepicker/build/jquery.datetimepicker.full.min.js')); ?>"></script>
<?php echo $__env->yieldContent('footer'); ?>
</body>

</html>
