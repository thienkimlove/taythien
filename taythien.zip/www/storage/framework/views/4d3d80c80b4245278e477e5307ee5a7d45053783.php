<?php $__env->startSection('content'); ?>

    <div class="feature">
        <div class="ttkpage-header">
            <img src="<?php echo e(url('frontend/images/img-tt.jpg')); ?>" alt="">
            <div class="container">
                <div class="row">
                    <h2>Tin tức</h2>
                    <p>Cập nhật những thông tin mới nhất về Tây Thiên Ký</p>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <img src="<?php echo e(url('frontend/images/p12+.png')); ?>" alt="">
            </div>
        </div>
        <div class="ttk-download">
            <a href="<?php echo e($settings['link_napthe']); ?>" class="napthe"></a>
            <a href="<?php echo e($settings['link_taigame']); ?>" class="taigame"></a>
            <a href="" class="giftcode" data-toggle="modal" data-target="#giftcode"></a>
        </div>
    </div>

    <div class="main articles">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="tab-ttsk">
                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs" role="tablist">
                            <li role="presentation" class="active"><a href="#tintuc" aria-controls="tintuc" role="tab" data-toggle="tab"><?php echo e($post->category->name); ?></a></li>

                        </ul>
                        <!-- Tab panes -->
                        <div class="tab-content">
                            <div role="tabpanel" class="tab-pane active" id="tintuc">
                                <div class="news-details">
                                    <?php echo $post->content; ?>

                                </div>
                                <?php if(count($relatedPosts)): ?>
                                    <div class="news-related">
                                        <h2>
                                            Tin liên quan
                                        </h2>
                                        <div class="row">
                                            <?php foreach($relatedPosts as $post): ?>
                                                <div class="col-md-4 rs-item col-sm-4">
                                                    <div class="thumbnail">
                                                        <img src="<?php echo e(url('img/cache/340x184', $post->image)); ?>" alt="<?php echo e($post->title); ?>">
                                                    </div>
                                                    <span class="date">
                                                         <i class="glyphicon glyphicon-time"></i>
                                                        <?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s',$post->updated_at)->format('d.m.Y')); ?>

                                                    </span>
                                                    <h3><?php echo e($post->title); ?></h3>
                                                    <p><?php echo e($post->desc); ?></p>
                                                    <a href="<?php echo e($post->slug.'.html'); ?>" class="ttk-more">
                                                        <i class="glyphicon glyphicon-arrow-right"></i>Xem thêm</a>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>