<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Setting</h1>
        </div>

    </div>
    <div class="row">
        <div class="col-lg-8">
            <div class="panel panel-default">
                <div class="panel-heading">
                    List all settings.
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Value</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach($settingContents as $settingContent): ?>
                                <tr>
                                    <td><?php echo e($settingContent->id); ?></td>
                                    <td><?php echo e($settingContent->key_name); ?></td>
                                    <td><?php echo e($settingContent->value); ?></td>
                                    <td>
                                        <button class="btn btn-primary btn-sm edit-setting" id-attr="<?php echo e($settingContent->id); ?>"  type="button">Edit</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="row">

                        <div class="col-sm-6"><?php echo $settingContents->render(); ?></div>
                    </div>

                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script>
        $(function(){
            $('.edit-setting').click(function(){
                window.location.href = window.baseUrl + '/admin/settings/' + $(this).attr('id-attr') + '/edit';
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>