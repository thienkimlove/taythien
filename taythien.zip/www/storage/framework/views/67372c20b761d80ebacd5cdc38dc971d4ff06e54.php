<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Setting</h1>
        </div>

    </div>
    <div class="row">
        <div class="col-lg-12">
                <h2>Edit</h2>
                <?php echo Form::model($setting, ['method' => 'PATCH', 'route' => ['admin.settings.update', $setting->id]]); ?>



            <div class="form-group">
                <?php echo Form::label('key_name', 'Name'); ?>

                <?php echo e($setting->key_name); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('value', 'Value'); ?>

                <?php echo Form::text('value', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::submit('Save', ['class' => 'btn btn-primary form-control']); ?>

            </div>
            <?php echo Form::close(); ?>



            <?php echo $__env->make('admin.list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>