<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-2 col-sm-2 col-xs-3">
               <img src="<?php echo e(url('frontend/images/garena.png')); ?>" alt="">
            </div>
            <div class="col-md-6  col-sm-7 col-xs-5">
                <p>
                    © Garena Online. Trademarks belong to their respective owners.
                    <br> All rights reserved.
                </p>
            </div>
            <div class="col-md-3  col-sm-2 col-xs-3">
                <img src="<?php echo e(url('frontend/images/logo_dev.png')); ?>" alt="" class="pull-right">
            </div>
            <div class="col-md-1  col-sm-1 col-xs-1">
                <img src="<?php echo e(url('frontend/images/p12+.png')); ?>" alt="" class="pull-right">
            </div>
        </div>
    </div>
</footer>
<!-- BacktoTOp -->
<span id="top-link-block" class="hidden">
        <a href="#top" class="well well-sm"  onclick="$('html,body').animate({scrollTop:0},'slow');return false;">
            <i class="glyphicon glyphicon-chevron-up"></i>
        </a>
    </span>
<!-- Modal -->
<!-- <div class="modal fade" id="homevideo" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" class="glyphicon glyphicon-remove"></span></button>
                <h4 class="modal-title" id="myModalLabel">Gioi thieu TTK</h4>
            </div>
            <div class="modal-body">
                <iframe width="560" height="315" src="https://www.youtube.com/embed/Zl6oHzb8RnU" frameborder="0" allowfullscreen></iframe>
            </div>
        </div>
    </div>
</div> -->