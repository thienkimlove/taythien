<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Game Contents</h1>
        </div>

    </div>
    <div class="row">
        <div class="col-lg-12">
            <?php if(!empty($game_content)): ?>
            <h2>Edit</h2>
            <?php echo Form::model($game_content, [
                'method' => 'PATCH',
                'route' => ['admin.game_contents.update', $game_content->id],
                'files' => true
             ]); ?>

            <?php else: ?>
                <h2>Add</h2>
                <?php echo Form::model($game_content = new App\GameContent, ['route' => ['admin.game_contents.store'], 'files' => true]); ?>

            <?php endif; ?>

            <div class="form-group">
                <?php echo Form::label('title', 'Title'); ?>

                <?php echo Form::text('title', null, ['class' => 'form-control']); ?>

            </div>


            <div class="form-group">
                <?php echo Form::label('type', 'Type'); ?>

                <?php echo Form::select('type', $types, null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('desc', 'Short Description'); ?>

                <?php echo Form::textarea('desc', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('addition_desc', 'Addition Description'); ?>

                <?php echo Form::textarea('addition_desc', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('content', 'Content'); ?>

                <?php echo Form::textarea('content', null, ['class' => 'form-control ckeditor']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('image', 'Image'); ?>

                <?php if($game_content->image): ?>
                    <img src="<?php echo e(url('img/cache/small/' . $game_content->image)); ?>" />
                    <hr>
                <?php endif; ?>
                <?php echo Form::file('image', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('icon', 'Icon'); ?>

                <?php if($game_content->icon): ?>
                    <img src="<?php echo e(url('img/cache/77x77/' . $game_content->icon)); ?>" />
                    <hr>
                <?php endif; ?>
                <?php echo Form::file('icon', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('video_url', 'Video URL'); ?>

                <?php echo Form::text('video_url', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('external_link', 'External Link'); ?>

                <?php echo Form::text('external_link', null, ['class' => 'form-control']); ?>

            </div>


            <div class="form-group">
                <?php echo Form::label('order', 'Order'); ?>

                <?php echo Form::select('order', $orders, null, ['class' => 'form-control']); ?>

            </div>


            <div class="form-group">
                <?php echo Form::submit('Save', ['class' => 'btn btn-primary form-control']); ?>

            </div>

            <?php echo Form::close(); ?>


            <?php echo $__env->make('admin.list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>