<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Posts</h1>
        </div>

    </div>
    <div class="row">
        <div class="col-lg-12">
            <?php if(!empty($post)): ?>
            <h2>Edit</h2>
            <?php echo Form::model($post, [
                'method' => 'PATCH',
                'route' => ['admin.posts.update', $post->id],
                'files' => true
             ]); ?>

            <?php else: ?>
                <h2>Add</h2>
                <?php echo Form::model($post = new App\Post, ['route' => ['admin.posts.store'], 'files' => true]); ?>

            <?php endif; ?>

            <div class="form-group">
                <?php echo Form::label('title', 'Title'); ?>

                <?php echo Form::text('title', null, ['class' => 'form-control']); ?>

            </div>


            <div class="form-group">
                <?php echo Form::label('category_id', 'Category'); ?>

                <?php echo Form::select('category_id', $categories, null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('desc', 'Short Description'); ?>

                <?php echo Form::textarea('desc', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('content', 'Content'); ?>

                <?php echo Form::textarea('content', null, ['class' => 'form-control ckeditor']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('image', 'Image'); ?>

                <?php if($post->image): ?>
                    <img src="<?php echo e(url('img/cache/small/' . $post->image)); ?>" />
                    <hr>
                <?php endif; ?>
                <?php echo Form::file('image', null, ['class' => 'form-control']); ?>

            </div>




            <div class="form-group">
                <?php echo Form::label('status', 'Publish'); ?>

                <?php echo Form::checkbox('status', null, null); ?>

            </div>



                <div class="form-group">
                <?php echo Form::submit('Save', ['class' => 'btn btn-primary form-control']); ?>

            </div>

            <?php echo Form::close(); ?>


            <?php echo $__env->make('admin.list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>