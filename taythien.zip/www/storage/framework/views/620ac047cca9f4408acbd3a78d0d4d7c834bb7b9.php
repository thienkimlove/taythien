<?php $__env->startSection('content'); ?>
    <div class="feature">
        <div class="ttkpage-header">
            <img src="<?php echo e(url('frontend/images/img-tv.jpg')); ?>" alt="">
            <div class="container">
                <div class="row">
                    <h2>Thư viện</h2>
                    <p>Khám phá tài nguyên phong phú của Tây Thiên Ký</p>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <img src="<?php echo e(url('frontend/images/p12+.png')); ?>" alt="">
            </div>
        </div>
        <div class="ttk-download">
            <a href="<?php echo e($settings['link_napthe']); ?>" class="napthe"></a>
            <a href="<?php echo e($settings['link_taigame']); ?>" class="taigame"></a>
            <a href="" class="giftcode" data-toggle="modal" data-target="#giftcode"></a>
        </div>
    </div>
    <div class="main thuvien">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="tab-ttsk tab-lib">
                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs" role="tablist">
                            <li role="presentation" class="active"><a href="#anhnen" aria-controls="anhnen" role="tab" data-toggle="tab">Ảnh nền</a></li>
                            <li role="presentation"><a href="#videos" aria-controls="videos" role="tab" data-toggle="tab">Videos</a></li>
                            <li role="presentation"><a href="#screenshots" aria-controls="screenshots" role="tab" data-toggle="tab">Screenshots</a></li>
                        </ul>
                        <!-- Tab panes -->
                        <div class="tab-content">
                            <div role="tabpanel" class="tab-pane active" id="anhnen">
                                <?php foreach($backgroundImages->chunk(2) as $backgroundImage): ?>
                                  <div class="row">
                                    <?php foreach($backgroundImage as $post): ?>
                                      <div class="col-md-6 col-sm-6">
                                        <div class="item">
                                            <a href="<?php echo e(url('img/cache/555x359', $post->image)); ?>" data-toggle="lightbox" data-gallery="anhnenglr">
                                                <span><?php echo e($post->title); ?></span>
                                            </a>
                                            <div class="ctn">
                                                <img src="<?php echo e(url('img/cache/555x359', $post->image)); ?>" alt="">

                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                                <?php endforeach; ?>
                            </div>
                            <div role="tabpanel" class="tab-pane" id="videos">
                                <?php foreach($videos->chunk(2) as $video): ?>
                                    <div class="row">
                                        <?php foreach($video as $post): ?>
                                            <div class="col-md-6 col-sm-6">
                                                <div class="item">
                                                    <a href="<?php echo e(url('img/cache/555x359', $post->image)); ?>" data-toggle="lightbox" data-gallery="anhnenglr">
                                                        <span><?php echo e($post->title); ?></span>
                                                    </a>
                                                    <div class="ctn">
                                                        <img src="<?php echo e(url('img/cache/555x359', $post->image)); ?>" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <div role="tabpanel" class="tab-pane" id="screenshots">
                                <?php foreach($screenshots->chunk(2) as $images): ?>
                                    <div class="row">
                                        <?php foreach($images as $image): ?>
                                            <div class="col-md-6 col-sm-6">
                                                <div class="item">
                                                    <a href="<?php echo e(url('img/cache/555x359', $image->image)); ?>" data-toggle="lightbox" data-gallery="anhnenglr">
                                                        <span><?php echo e($image->title); ?></span>
                                                    </a>
                                                    <div class="ctn">
                                                        <img src="<?php echo e(url('img/cache/555x359', $image->image)); ?>" alt="">

                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>