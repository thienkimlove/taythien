<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Posts</h1>
        </div>

    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <div class="input-group custom-search-form">
                        <?php echo Form::open(['method' => 'GET', 'route' =>  ['admin.posts.index'] ]); ?>

                        <span class="input-group-btn">
                            <input type="text" value="<?php echo e($searchPost); ?>" name="q" class="form-control" placeholder="Search post..">

                            <button class="btn btn-default" type="submit">
                                <i class="fa fa-search"></i>
                            </button>
                        </span>
                        <input type="hidden" name="category_id" value="<?php echo e($categoryId); ?>" />

                        <?php echo Form::close(); ?>

                    </div>
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Title</th>
                                <th>Category</th>
                                <th>Desc</th>
                                <th>Image</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach($posts as $post): ?>
                                <tr>
                                    <td><?php echo e($post->id); ?></td>
                                    <td><?php echo e($post->title); ?></td>
                                    <td><?php echo e($post->category->name); ?></td>
                                    <td><?php echo str_limit($post->desc, 200); ?></td>
                                    <td><img src="<?php echo e(url('img/cache/small/' . $post->image)); ?>" /></td>
                                    <td><?php echo e(($post->status) ? 'Yes' : 'No'); ?></td>
                                    <td>
                                        <button id-attr="<?php echo e($post->id); ?>" class="btn btn-primary btn-sm edit-post" type="button">Edit</button>&nbsp;
                                        <?php echo Form::open(['method' => 'DELETE', 'route' => ['admin.posts.destroy', $post->id]]); ?>

                                        <button type="submit" class="btn btn-danger btn-mini">Delete</button>
                                        <?php echo Form::close(); ?>

                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>

                    </div>
                    <div class="row">

                        <div class="col-sm-6"><?php echo $posts->render(); ?></div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <button class="btn btn-primary add-post" type="button">Add</button>
                        </div>
                    </div>


                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <script>
        $(function(){
            $('.add-post').click(function(){
                window.location.href = window.baseUrl + '/admin/posts/create';
            });
            $('.edit-post').click(function(){
                window.location.href = window.baseUrl + '/admin/posts/' + $(this).attr('id-attr') + '/edit';
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>