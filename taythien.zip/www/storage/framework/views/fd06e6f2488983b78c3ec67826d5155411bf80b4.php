<?php $__env->startSection('content'); ?>
    <div class="feature">
        <div class="ttkpage-header">
            <img src="<?php echo e(url('frontend/images/img-tanthu.jpg')); ?>" alt="">
            <div class="container">
                <div class="row">
                    <h2>Tân thủ</h2>
                    <p>Tìm hiểu những hướng dẫn cho người chơi mới</p>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <img src="<?php echo e(url('frontend/images/p12+.png')); ?>" alt="">
            </div>
        </div>
        <div class="ttk-download">
            <a href="<?php echo e($settings['link_napthe']); ?>" class="napthe"></a>
            <a href="<?php echo e($settings['link_taigame']); ?>" class="taigame"></a>
            <a href="" class="giftcode" data-toggle="modal" data-target="#giftcode"></a>
        </div>
    </div>
    <div class="main tanthu">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="tab-ttsk tab-tanthu">
                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs" role="tablist">
                            <?php foreach($gamers as $key => $gamer): ?>
                            <li role="presentation" class="<?php echo e(($key == 0) ? 'active' : ''); ?>"><a href="#tab<?php echo e($key); ?>" aria-controls="tab<?php echo e($key); ?>" role="tab" data-toggle="tab"><?php echo e($gamer->title); ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                        <!-- Tab panes -->
                        <div class="tab-content">
                            <?php foreach($gamers as $key => $gamer): ?>
                            <div role="tabpanel" class="<?php echo e(($key == 0) ? 'tab-pane active' : 'tab-pane'); ?>" id="tab<?php echo e($key); ?>">
                                <?php echo $gamer->content; ?>

                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('frontend.info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>