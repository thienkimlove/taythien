<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('max_execution_time', 0);
echo phpversion("mongo"), "\n";
$username = 'xmasfo3';
$password = 'IhecjyLEij8Q7UH9DIdg';
$host = '203.162.56.82:30000';
$database = 'admin';
$client = new MongoClient("mongodb://$username:$password@$host", ['socketTimeoutMS' => 10000000]);

$db = $client->log_20161118;

$collection = $db->cslogs;

// search for fruits
//$fruitQuery = array('_id' => '582de210233176156970d413');

$cursor = $collection->count(array('type' => 501, 'opts.forf' => 0));

die($cursor);
